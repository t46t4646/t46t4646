# Example configuration, just list what pairs/directions you want to test:
PAIRS=( nno-nob nob-nno )
