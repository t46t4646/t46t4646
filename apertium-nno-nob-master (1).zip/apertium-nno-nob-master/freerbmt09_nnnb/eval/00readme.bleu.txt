
Usage: bleu.pl <file>

********************

Input file format:

SOURCE < source sentence >
REF < reference translation >
TRANS < translation >

Examples:
SOURCE Hjelp oss å holde skilt og karttavler i god stand.
REF Help us to keep signs and maps in good repair.
REF Help us to keep signs and posted maps in good shape.
TRANS Help us to keep signs and map boards in a good condition.

SOURCE På Byfjellene kan du raste, slå leir og overnatte.
REF In the city mountains you can rest, set up camp and spend the night.
REF You may rest, camp and spend the night in Byfjellene.
TRANS You can rest camp and spend the night on Byfjellene.

